import React, { useState, useEffect, useCallback } from "react"; // Added useCallback
import "./App.css";
// Import your images from the assets folder
import bkalertLogo from "./assets/bkalert-logo.jpg";
import feedbackQR from "./assets/feedback.jpg"; // Import feedback QR
import addQR from "./assets/add.jpg"; // Import add article QR

// --- Helper Functions (Outside Component) ---

// Normalize function to remove accents
const removeVietnameseTones = (str) => {
  if (!str) return "";
  const map = {
    a: "áàảãạâấầẩẫậăắằẳẵặ",
    e: "éèẻẽẹêếềểễệ",
    i: "íìỉĩị",
    o: "óòỏõọôốồổỗộơớờở̃ợ",
    u: "úùủũụưứừửữự",
    y: "ýỳỷỹỵ",
    d: "đ",
  };
  // Ensure map lookup is case-insensitive
  return str
    .split("")
    .map((char) => {
      const lowerChar = char.toLowerCase();
      for (let key in map) {
        if (map[key].includes(lowerChar)) return key; // Use includes for robustness
      }
      return char;
    })
    .join("");
};

// Function to escape special regex characters
function escapeRegExp(string) {
  if (!string) return "";
  // Escapes characters that have special meaning in regular expressions
  return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); // $& means the whole matched string
}

// --- Debounce Hook --- (Helper Hook for Search Input)
function useDebounce(value, delay) {
  const [debouncedValue, setDebouncedValue] = useState(value);

  useEffect(() => {
    // Set timeout to update debounced value after delay
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    // Cancel the timeout if value changes (or component unmounts)
    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]); // Re-run effect only if value or delay changes

  return debouncedValue;
}

// --- Initial Data (Standardized) ---
const initialArticles = [
  {
    // Article 1
    title: "Tấn công mạng và giải pháp phòng chống tốt nhất hiện nay",
    summary:
      "Bài viết này trình bày về các cuộc tấn công mạng phổ biến và đề xuất những giải pháp phòng chống hiệu quả cho doanh nghiệp.",
    image:
      "https://viettelidc.com.vn/uploadimage/Root/root/tan-cong-mang-01.jpg",
    link: "https://viettelidc.com.vn/tin-tuc/tan-cong-mang-va-giai-phap-phong-chong-tot-nhat",
    year: 2024,
  },
  {
    // Article 2
    title: "Toàn bộ kiến thức về Tấn Công Mạng (Cyber-attack)",
    summary:
      "Bài viết cung cấp kiến thức tổng quan về tấn công mạng, các hình thức phổ biến và giải pháp phòng chống hiệu quả.",
    image:
      "https://s.cystack.net/resource/home/content/10141838/174477-cyberattack.jpg",
    link: "https://cystack.net/vi/blog/tan-cong-mang-cyber-attack",
    year: 2023,
  },
  {
    // Article 3
    title: "Tấn công qua mạng là gì?",
    summary:
      "Giải thích về tấn công mạng, các loại hình tấn công phổ biến và cách bảo vệ hệ thống trước các mối đe dọa.",
    image:
      "https://drive.google.com/file/d/1n04xE0mKdoTNpetB9SPXQq-eyRtZelIA/view?usp=drive_link",
    link: "https://www.microsoft.com/vi-vn/security/business/security-101/what-is-a-cyberattack",
    year: 2025,
  },
  {
    // Article 4
    title: "10 chiến lược tránh các mối đe dọa an ninh mạng",
    summary:
      "Bài viết liệt kê 10 chiến lược giúp tránh các mối đe dọa an ninh mạng và bảo vệ hệ thống hiệu quả.",
    image:
      "https://media.geeksforgeeks.org/wp-content/uploads/20240912173547/10-Strategies-to-Avoid-Cyber-Security-Threats-in-2024.webp",
    link: "https://www.geeksforgeeks.org/strategies-to-avoid-cyber-security-threats/",
    year: 2024,
  },
  {
    // Article 5
    title: "10 cách ngăn chặn tấn công mạng",
    summary:
      "Bài viết đề xuất 10 phương pháp giúp ngăn chặn các cuộc tấn công mạng và bảo vệ doanh nghiệp.",
    image: "https://leaf-it.com/wp-content/uploads/2020/02/image1-1024x575.jpg",
    link: "https://leaf-it.com/10-ways-prevent-cyber-attacks/",
    year: 2022,
  },
  {
    // Article 6
    title: "16 loại tấn công mạng và cách phòng ngừa",
    summary:
      "Bài viết mô tả 16 loại tấn công mạng phổ biến và cung cấp hướng dẫn về cách phòng ngừa chúng.",
    image:
      "https://www.techtarget.com/rms/onlineimages/common_types_of_cyberattacks-f.png",
    link: "https://www.techtarget.com/searchsecurity/tip/6-common-types-of-cyber-attacks-and-how-to-prevent-them",
    year: 2024,
  },
  {
    // Article 7
    title: "Tấn công DDoS là gì?",
    summary:
      "Bài viết mô tả chi tiết về tấn công từ chối dịch vụ phân tán (DDoS), cơ chế hoạt động và cách bảo vệ hệ thống.",
    image: "", // Intentionally empty as per original data
    link: "https://www.microsoft.com/vi-vn/security/business/security-101/what-is-a-ddos-attack",
    year: 2025,
  },
  {
    // Article 8
    title: "DDoS là gì? Tấn công DDoS bị phạt bao nhiêu tiền?",
    summary:
      "Bài viết giải thích khái niệm DDoS, các mức phạt theo pháp luật khi thực hiện hành vi tấn công DDoS tại Việt Nam.",
    image:
      "https://cdn.thuvienphapluat.vn//uploads/khoinghiep/2024/11/26/freecompress-freecompress-ddos.png",
    link: "https://thuvienphapluat.vn/phap-luat-doanh-nghiep/cau-hoi-thuong-gap/ddos-la-gi-tan-cong-ddos-bi-phat-bao-nhieu-tien-6601.html",
    year: 2024,
  },
  {
    // Article 9
    title: "DDoS là gì và những điều bạn cần biết",
    summary:
      "Giới thiệu khái niệm DDoS, cách thức hoạt động, hậu quả và cách phòng tránh các cuộc tấn công này.",
    image:
      "https://cdn2.fptshop.com.vn/unsafe/Uploads/images/tin-tuc/180765/Originals/DDoS-la-%20gi-2.png",
    link: "https://fptshop.com.vn/tin-tuc/danh-gia/ddos-la-gi-156213",
    year: 2024,
  },
  {
    // Article 10
    title: "Null Pointer Exception là gì? Nguyên nhân và cách khắc phục",
    summary:
      "Giải thích về Null Pointer Exception, lý do gây ra và các phương pháp để xử lý lỗi này trong lập trình.",
    image:
      "https://png.pngwing.com/pngs/18/595/png-transparent-null-pointer-handle-java-programming-language-exceptions-miscellaneous-angle-text.png",
    link: "https://www.geeksforgeeks.org/null-pointer-exception-in-java/",
    year: 2025,
  },
  {
    // Article 11
    title: "SQL Injection",
    summary:
      "Giải thích về SQL Injection, cách tấn công này hoạt động và các biện pháp ngăn chặn hiệu quả.",
    image:
      "https://media.geeksforgeeks.org/wp-content/uploads/20230321182818/SQL-Injection.jpg",
    link: "https://www.geeksforgeeks.org/sql-injection/",
    year: 2025,
  },
  {
    // Article 12
    title: "SQL Injection",
    summary:
      "Tổng quan về tấn công SQL Injection từ OWASP, bao gồm kỹ thuật, hậu quả và cách bảo vệ hệ thống.",
    image:
      "https://owasp.org/www-community/assets/images/attacks/sql-injection-HPP.png",
    link: "https://owasp.org/www-community/attacks/SQL_Injection",
    year: 2025,
  },
  {
    // Article 13
    title: "What is SQL Injection?",
    summary:
      "Bài viết chi tiết từ Cloudflare về tấn công SQL Injection, các dạng phổ biến và cách phòng tránh.",
    image:
      "https://www.cloudflare.com/img/learning/security/threats/sql-injection-attack/sql-injection-infographic.png",
    link: "https://www.cloudflare.com/learning/security/threats/sql-injection/",
    year: 2023,
  },
  {
    // Article 14
    title: "Null Pointer Exception là gì? Cách fix lỗi NullPointerException",
    summary:
      "IT viec giải thích chi tiết về Null Pointer Exception và cung cấp các giải pháp khắc phục lỗi này trong Java.",
    image:
      "https://png.pngwing.com/pngs/18/595/png-transparent-null-pointer-handle-java-programming-language-exceptions-miscellaneous-angle-text.png",
    link: "https://itviec.com/blog/null-pointer-exception-la-gi/",
    year: 2024,
  },
  {
    // Article 15
    title: "Brute Force Approach: Pros and Cons",
    summary:
      "Bài viết giới thiệu về phương pháp Brute Force, ưu điểm, nhược điểm và ứng dụng của phương pháp này trong giải quyết vấn đề.",
    image: "", // Intentionally empty
    link: "https://www.geeksforgeeks.org/brute-force-approach-and-its-pros-and-cons/",
    year: 2024,
  },
  {
    // Article 16
    title: "Brute Force là gì và cách phòng tránh",
    summary:
      "Bài viết giới thiệu khái niệm, nguyên lý và cách bảo vệ trước các cuộc tấn công Brute Force.",
    image:
      "https://cdn2.fptshop.com.vn/unsafe/800x0/brute_force_1_901dd3cf44.jpg",
    link: "https://fptshop.com.vn/tin-tuc/danh-gia/brute-force-la-gi-156028",
    year: 2024,
  },
  {
    // Article 17
    title: "What is a Brute Force Attack?",
    summary:
      "Cloudflare giải thích chi tiết về các cuộc tấn công Brute Force, các dấu hiệu nhận biết và biện pháp phòng chống.",
    image:
      "https://www.cloudflare.com/img/learning/security/threats/brute-force-attack/brute-force-cracking-time.png",
    link: "https://www.cloudflare.com/learning/bots/brute-force-attack/",
    year: 2025,
  },
  {
    // Article 18
    title: "Brute Force Attack là gì và cách chống cho WordPress",
    summary:
      "Bài viết giải thích rõ về tấn công Brute Force nhắm vào WordPress và cung cấp các biện pháp hiệu quả để bảo vệ trang web.",
    image:
      "https://lh3.googleusercontent.com/proxy/b_9-34wczomPBP6DnEPCubFP5Kor8r1Ly9pz9K5PD0mzqZPd9r-_Dm-iNYTbYxQ8gQ-UF-ZcUw0RAlu9fhqOIMkG45gV1yiY82jhC_4dsKp2WO2ZLFcspZJG-s2wEaB78nF43wtxOAdwmSO1IlWsndOLEYVz_phSwTXwJtLn25JPzZKEas5Lur0", // Placeholder-like URL
    link: "https://viettelidc.com.vn/tin-tuc/brute-force-attack-la-gi-va-lam-the-nao-de-chong-cho-wordpress",
    year: 2019,
  },
  {
    // Article 19
    title: "NullPointerException in Java",
    summary:
      "Baeldung cung cấp hướng dẫn chi tiết về Null Pointer Exception trong Java, nguyên nhân và cách tránh lỗi.",
    image:
      "https://png.pngwing.com/pngs/18/595/png-transparent-null-pointer-handle-java-programming-language-exceptions-miscellaneous-angle-text.png",
    link: "https://www.baeldung.com/java-nullpointerexception",
    year: 2024,
  },
  {
    // Article 20
    title: "Tìm hiểu về tấn công khai thác lỗ hổng File Inclusion",
    summary:
      "Bài viết giải thích rõ về tấn công File Inclusion, cách thức khai thác và biện pháp bảo vệ hệ thống.",
    image:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRrQ0rzXsVewjWvbARQZJX06tmBM7Sdwswumg&s",
    link: "https://viettelidc.com.vn/tin-tuc/tim-hieu-ve-tan-cong-khai-thac-lo-hong-file-inclusion",
    year: 2019,
  },
  {
    // Article 21
    title: "XSS là gì? Cách kiểm tra và ngăn chặn",
    summary:
      "Bài viết cung cấp thông tin về tấn công Cross-Site Scripting (XSS), cách kiểm tra và giải pháp ngăn chặn hiệu quả.",
    image: "https://viettelidc.com.vn/uploadimage/Root/root/xss-la-gi-2.png",
    link: "https://viettelidc.com.vn/tin-tuc/xss-la-gi-cach-kiem-tra-va-ngan-chan",
    year: 2024,
  },
  {
    // Article 22
    title: "XSS là gì? Những điều cần biết về Cross-Site Scripting",
    summary:
      "Bài viết giới thiệu chi tiết về Cross-Site Scripting (XSS), các hình thức tấn công phổ biến và biện pháp phòng ngừa.",
    image:
      "https://cdn2.fptshop.com.vn/unsafe/Uploads/images/tin-tuc/175381/Originals/XSS-la-gi-4.jpg",
    link: "https://fptshop.com.vn/tin-tuc/danh-gia/xss-la-gi-175381",
    year: 2024,
  },
  {
    // Article 23
    title: "What is Cross-Site Scripting (XSS)?",
    summary:
      "Giới thiệu chi tiết về Cross-Site Scripting (XSS), các dạng phổ biến, tác hại và cách phòng tránh hiệu quả.",
    image:
      "https://media.geeksforgeeks.org/wp-content/uploads/20190516152959/Cross-Site-ScriptingXSS.png",
    link: "https://www.geeksforgeeks.org/what-is-cross-site-scripting-xss/",
    year: 2022,
  },
  {
    // Article 24
    title: "Cross-Site Scripting (XSS)",
    summary:
      "Bài viết từ Cloudflare giải thích rõ về Cross-Site Scripting, các ví dụ tấn công và giải pháp bảo vệ ứng dụng web.",
    image:
      "https://www.cloudflare.com/img/learning/security/threats/cross-site-scripting/xss-attack.png",
    link: "https://www.cloudflare.com/learning/security/threats/cross-site-scripting/",
    year: 2025,
  },
  {
    // Article 25
    title: "Cross-Site Scripting (XSS)",
    summary:
      "OWASP cung cấp tổng quan đầy đủ về tấn công Cross-Site Scripting (XSS), cách thức hoạt động và các biện pháp ngăn chặn.",
    image:
      "https://cdn.prod.website-files.com/5ff66329429d880392f6cba2/67614de3b9a2a1125eb4caaf_613afbb3f677add6ebeb2123_Cross-Site%2520Scripting%2520(XSS)%2520example.png",
    link: "https://owasp.org/www-community/attacks/xss/",
    year: 2025,
  },
  {
    // Article 26
    title: "Cross-Site Scripting (XSS)",
    summary:
      "PortSwigger cung cấp tài liệu chi tiết về Cross-Site Scripting, các kỹ thuật khai thác và hướng dẫn cách phòng ngừa.",
    image:
      "https://drive.google.com/file/d/1Dohy70kRCtxfjcDUg52yVz4WMVOn5lrN/view?usp=drive_link",
    link: "https://portswigger.net/web-security/cross-site-scripting",
    year: 2025,
  },
  {
    // Article 27
    title: "Website Defacement Attack",
    summary:
      "Giới thiệu chi tiết về cuộc tấn công làm biến dạng website (defacement), cách nhận biết và phòng chống hiệu quả.",
    image:
      "https://www.imperva.com/learn/wp-content/uploads/sites/13/2020/02/100932282_nhs.jpg",
    link: "https://www.imperva.com/learn/application-security/website-defacement-attack/",
    year: 2025,
  },
  {
    // Article 28
    title: "Website Defacement",
    summary:
      "Bài viết cung cấp hướng dẫn và thông tin về việc nhận diện, ngăn chặn các cuộc tấn công làm biến dạng trang web.",
    image: "", // Intentionally empty
    link: "https://www.cyber.gc.ca/en/guidance/website-defacement-itsap00060",
    year: 2024, // Assuming string year '2024' meant number
  },
  {
    // Article 29
    title: "Birthday Attack in Cryptography",
    summary:
      "GeeksforGeeks giới thiệu về Birthday Attack, nguyên lý hoạt động và các biện pháp phòng ngừa trong mật mã học.",
    image: "https://library.mosse-institute.com/_images/collision_attack.jpg",
    link: "https://www.geeksforgeeks.org/birthday-attack-in-cryptography/",
    year: 2023, // Assuming string year '2023' meant number
  },
  {
    // Article 30
    title: "What is NullPointerException?",
    summary:
      "Oracle giải thích về NullPointerException trong tài liệu Java chính thức.",
    image:
      "https://png.pngwing.com/pngs/18/595/png-transparent-null-pointer-handle-java-programming-language-exceptions-miscellaneous-angle-text.png",
    link: "https://docs.oracle.com/javase/8/docs/api/java/lang/NullPointerException.html",
    year: 2025, // Assuming year
  },
  {
    // Article 31
    title: "What is Birthday Attack?",
    summary:
      "Giải thích rõ khái niệm Birthday Attack, cơ chế và ý nghĩa của nó trong an ninh mạng và mã hóa thông tin.",
    image:
      "https://ccoe.dsci.in/storage/blogs/May2024/c14V8349Q9TorffppLE1.jpg",
    link: "https://ccoe.dsci.in/blog/what-is-birthday-attack",
    year: 2025, // Assuming string year meant number
  },
  {
    // Article 32 - Standardized from description/imageUrl/url
    title: "How to prevent Birthday Attacks",
    summary:
      "Bài viết hướng dẫn các biện pháp phòng chống tấn công Birthday Attack một cách hiệu quả.",
    image:
      "https://miro.medium.com/v2/resize:fit:720/format:webp/0*3GpuKk1LHcHCWdsM.jpg",
    link: "https://medium.com/@Infosec-Train/how-to-prevent-birthday-attacks-d8d0a52b6299",
    year: 2023, // Assuming string year meant number
  },
  {
    // Article 33 - Standardized from description/imageUrl/url
    title: "Birthday Attack: Everything you need to know",
    summary:
      "Giới thiệu toàn diện về Birthday Attack, cách thức tấn công và biện pháp bảo vệ hệ thống trước mối đe dọa này.",
    image:
      "https://www.internetsecurity.tips/wp-content/uploads/2020/06/What-is-a-Birthday-attack-and-How-to-Prevent-It.png",
    link: "https://www.internetsecurity.tips/birthday-attack/",
    year: 2020, // Assuming string year meant number
  },
  {
    // Article 34
    title: "What is ARP Spoofing (ARP Poisoning) Attack?",
    summary:
      "GeeksforGeeks giải thích về ARP Spoofing, cách thức hoạt động, hậu quả và biện pháp phòng tránh hiệu quả.",
    image:
      "https://media.geeksforgeeks.org/wp-content/uploads/20230815092759/GFG-ARP-spoofing--(2).png",
    link: "https://www.geeksforgeeks.org/what-is-arp-spoofing-arp-poisoning-attack/",
    year: 2023, // Assuming string year meant number
  },
  {
    // Article 35
    title: "ARP Poisoning",
    summary:
      "Bài viết giới thiệu về ARP Poisoning, cơ chế tấn công và các giải pháp phòng ngừa bảo mật mạng.",
    image:
      "https://www.okta.com/sites/default/files/media/image/2021-04/ARPPoisoningSpoofing.png",
    link: "https://www.okta.com/identity-101/arp-poisoning/",
    year: 2024, // Assuming string year meant number
  },
  {
    // Article 36
    title: "How to Avoid ARP Poisoning",
    summary:
      "GeeksforGeeks cung cấp hướng dẫn chi tiết để ngăn chặn và phòng chống các cuộc tấn công ARP Poisoning.",
    image:
      "https://media.geeksforgeeks.org/wp-content/uploads/20220307181043/WaystopreventARPPoisoningAttack.PNG",
    link: "https://www.geeksforgeeks.org/how-to-avoid-arp-poisoning/",
    year: 2022, // Assuming string year meant number
  },
  {
    // Article 37
    title: "ARP Spoofing",
    summary:
      "Bài viết từ Imperva về kỹ thuật tấn công ARP Spoofing, hậu quả tiềm ẩn và các biện pháp bảo vệ hệ thống.",
    image:
      "https://www.imperva.com/learn/wp-content/uploads/sites/13/2020/03/thumbnail_he-ARP-spoofing-attacker-pretends-to-be-both-sides-of-a-network-communication-channel.jpg",
    link: "https://www.imperva.com/learn/application-security/arp-spoofing/",
    year: 2025, // Assuming string year meant number
  },
  {
    // Article 38
    title: "Session Hijacking",
    summary:
      "GeeksforGeeks giải thích chi tiết về Session Hijacking, cơ chế tấn công, tác động và cách phòng ngừa hiệu quả.",
    image: "https://www.geeksforgeeks.org/wp-content/uploads/session1.png",
    link: "https://www.geeksforgeeks.org/session-hijacking/",
    year: 2022, // Assuming string year meant number
  },
  {
    // Article 39
    title: "Session Hijacking Attack",
    summary:
      "OWASP cung cấp thông tin đầy đủ về Session Hijacking, các kỹ thuật khai thác và phương pháp phòng ngừa.",
    image:
      "https://owasp.org/www-community/assets/images/attacks/session-hijacking.jpg",
    link: "https://owasp.org/www-community/attacks/Session_hijacking_attack",
    year: 2023, // Assuming string year meant number
  },
  {
    // Article 40
    title: "Session Hijacking",
    summary:
      "Bài viết của Imperva mô tả về Session Hijacking, các dấu hiệu nhận biết và biện pháp phòng chống bảo vệ ứng dụng web.",
    image:
      "https://www.imperva.com/learn/wp-content/uploads/sites/13/2019/01/Clickjacking.png",
    link: "https://www.imperva.com/learn/application-security/session-hijacking/",
    year: 2025, // Assuming string year meant number
  },
  {
    // Article 41
    title: "Dictionary Attack: What is it and How to Prevent It?",
    summary:
      "Bài viết từ Norton giải thích về Dictionary Attack, cách hoạt động và các phương pháp phòng tránh hiệu quả.",
    image:
      "https://us.norton.com/content/dam/blogs/images/norton/am/dictionary-attacks-explained.png",
    link: "https://us.norton.com/blog/emerging-threats/dictionary-attack",
    year: 2022, // Assuming string year meant number
  },
  // Add any other articles here following the standard format
];

// --- React Component ---

export default function App() {
  // --- State Variables ---
  const [clickCount, setClickCount] = useState(() => {
    const saved = localStorage.getItem("bkAlertClickCount");
    return saved ? parseInt(saved, 10) : 0;
  });
  const [searchKeyword, setSearchKeyword] = useState("");
  const debouncedSearchKeyword = useDebounce(searchKeyword, 300); // Debounced keyword
  const [searchYear, setSearchYear] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10; // Keep items per page reasonable
  const [filteredArticles, setFilteredArticles] = useState(initialArticles);
  const [showQR, setShowQR] = useState(false); // State for the general QR popup
  const [currentQR, setCurrentQR] = useState(null); // 'feedback' or 'add'

  // --- Effects ---
  // Persist click count
  useEffect(() => {
    localStorage.setItem("bkAlertClickCount", clickCount.toString());
  }, [clickCount]);

  // Increment click count on mount
  useEffect(() => {
    setClickCount((prev) => prev + 1);
  }, []);

  // Filter articles (using Debounced Keyword and Defensive Coding)
  useEffect(() => {
    // Use the DEBOUNCED keyword for filtering
    const normalizedSearchKeyword = removeVietnameseTones(
      debouncedSearchKeyword.toLowerCase()
    );

    const filtered = initialArticles.filter((article) => {
      // Safely access title and summary, providing empty string if null/undefined
      const titleText = article.title || "";
      // Use summary preferentially, but don't need description fallback if data is standardized
      const summaryText = article.summary || "";

      const normalizedTitle = removeVietnameseTones(titleText.toLowerCase());
      const normalizedSummary = removeVietnameseTones(
        summaryText.toLowerCase()
      );

      const matchesKeyword = normalizedSearchKeyword
        ? normalizedTitle.includes(normalizedSearchKeyword) ||
          normalizedSummary.includes(normalizedSearchKeyword)
        : true; // Match if search is empty

      // Safely access year
      const yearString = article.year?.toString() || "";
      const matchesYear = searchYear ? yearString === searchYear : true; // Match if year search is empty

      return matchesKeyword && matchesYear;
    });

    setFilteredArticles(filtered);
    setCurrentPage(1); // Reset to page 1 on new search
    // Update dependency array to use the debounced keyword
  }, [debouncedSearchKeyword, searchYear]);

  // --- Highlighting Function (More Robust) ---
  // useCallback ensures the function reference is stable unless dependencies change
  const highlightText = useCallback(
    (text) => {
      const textToProcess = String(text || ""); // Ensure it's a string

      // Use the *non-debounced* keyword for instant highlighting feedback as user types
      const currentSearchKeyword = searchKeyword;

      if (!currentSearchKeyword || !textToProcess) {
        return textToProcess; // No highlight if no keyword or text
      }

      const escapedKeyword = escapeRegExp(currentSearchKeyword);
      if (!escapedKeyword) {
        return textToProcess; // Return original if escaped keyword is empty
      }

      try {
        // Create regex with escaped keyword, global and case-insensitive flags
        const regex = new RegExp(`(${escapedKeyword})`, "gi");

        // Additional check: Ensure textToProcess is actually a string before split
        if (typeof textToProcess !== "string") {
          console.error(
            "highlightText: textToProcess is not a string:",
            textToProcess
          );
          return textToProcess;
        }

        const parts = textToProcess.split(regex);

        // Filter out empty strings that can result from split, before mapping
        return parts
          .filter((part) => part)
          .map((part, index) => {
            // Check if the part matches the original keyword (case-insensitive)
            if (part.toLowerCase() === currentSearchKeyword.toLowerCase()) {
              return (
                <span
                  key={`${part}-${index}`}
                  style={{ backgroundColor: "yellow" }}
                >
                  {part}
                </span>
              );
            }
            // Return non-matching parts as plain text fragments
            return (
              <React.Fragment key={`${part}-${index}`}>{part}</React.Fragment>
            );
          });
      } catch (error) {
        console.error(
          "Error during highlighting:",
          error,
          "Text:",
          textToProcess,
          "Keyword:",
          currentSearchKeyword
        );
        return textToProcess; // Return original text if any error occurs
      }
      // Dependency: searchKeyword (non-debounced) for instant visual feedback
    },
    [searchKeyword]
  );

  // --- Pagination Logic ---
  const totalPages = Math.ceil(filteredArticles.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  // Ensure paginatedArticles doesn't error if filteredArticles is empty
  const paginatedArticles =
    filteredArticles.length > 0
      ? filteredArticles.slice(startIndex, startIndex + itemsPerPage)
      : [];

  // --- Grouping by Year ---
  const groups = {};
  paginatedArticles.forEach((article) => {
    const year = article.year || "Unknown Year"; // Handle missing year
    if (!groups[year]) groups[year] = [];
    groups[year].push(article);
  });
  // Sort years: Place "Unknown Year" last, sort others descending
  const sortedYears = Object.keys(groups).sort((a, b) => {
    if (a === "Unknown Year") return 1;
    if (b === "Unknown Year") return -1;
    return Number(b) - Number(a);
  });

  // --- Pagination Number Generation ---
  const getPageNumbers = () => {
    const pageNumbers = [];
    const maxPagesToShow = 5; // Max number of page buttons to show
    const halfPagesToShow = Math.floor(maxPagesToShow / 2);

    if (totalPages <= 1) return []; // No buttons if 0 or 1 page
    if (totalPages <= maxPagesToShow) {
      for (let i = 1; i <= totalPages; i++) pageNumbers.push(i);
    } else {
      let startPage = Math.max(1, currentPage - halfPagesToShow);
      let endPage = Math.min(totalPages, currentPage + halfPagesToShow);
      if (currentPage <= halfPagesToShow + 1)
        endPage = maxPagesToShow - (startPage === 1 ? 0 : 1); // Adjust end near start
      if (currentPage + halfPagesToShow >= totalPages - 1)
        startPage =
          totalPages - maxPagesToShow + (endPage === totalPages ? 1 : 2); // Adjust start near end

      if (startPage > 1) {
        pageNumbers.push(1);
        if (startPage > 2) pageNumbers.push("...");
      }
      for (let i = startPage; i <= endPage; i++) pageNumbers.push(i);
      if (endPage < totalPages) {
        if (endPage < totalPages - 1) pageNumbers.push("...");
        pageNumbers.push(totalPages);
      }
    }
    return pageNumbers;
  };

  // --- Event Handlers ---
  const handleSearchInput = (e) => {
    setSearchKeyword(e.target.value); // Update search keyword immediately for input field
  };
  const handleSearchYear = (e) => {
    setSearchYear(e.target.value); // Update year immediately
  };
  const handleClearSearch = () => {
    setSearchKeyword("");
    setSearchYear("");
  };
  const handlePageChange = (page) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
      window.scrollTo(0, 0); // Scroll to top on page change
    }
  };
  // Toggle QR popup (used by footer and pen bubble in this version)
  const toggleQR = (qrType) => {
    if (showQR && currentQR === qrType) {
      setShowQR(false);
      setCurrentQR(null);
    } else {
      setCurrentQR(qrType);
      setShowQR(true);
    }
  };

  // --- JSX Return ---
  return (
    <div className="App">
      {/* Header */}
      <header>
        <div className="click-counter">🔍 {clickCount.toLocaleString()}</div>
        <img src={bkalertLogo} alt="BKAlert Logo" className="bkalert-logo" />
        <h1>BKAlert</h1>
        <h1>Knowledge is the best firewall against cyber criminals</h1>
      </header>

      {/* Search Bar */}
      <div className="search-bar">
        <input
          type="text"
          placeholder="Search by keyword (accent insensitive)"
          value={searchKeyword} // Controlled input uses non-debounced value
          onChange={handleSearchInput}
        />
        <input
          type="number"
          placeholder="Search by year"
          value={searchYear}
          onChange={handleSearchYear}
        />
        <button onClick={handleClearSearch}>Clear</button>
      </div>

      {/* Main Content */}
      <main>
        {filteredArticles.length === 0 &&
        (debouncedSearchKeyword || searchYear) ? (
          <p>No articles found matching your search criteria.</p>
        ) : (
          sortedYears.map((year) => (
            <div key={year}>
              <h2 className="year-header">{year}</h2>
              <div className="news-grid">
                {groups[year].map((article, index) => (
                  <article
                    key={`${year}-${article.title}-${index}`}
                    className="card"
                  >
                    {" "}
                    {/* Improved key */}
                    <img
                      src={article.image || "./assets/default-image.jpg"} // Provide a path to a default image
                      alt={article.title || "Article Image"} // Default alt text
                      onError={(e) => {
                        e.target.onerror = null; // Prevent infinite loop
                        e.target.src = "./assets/default-image.jpg"; // Path to your default image
                      }}
                    />
                    <div className="content">
                      <h3>
                        <a
                          href={article.link}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          {highlightText(article.title)}
                        </a>
                      </h3>
                      {/* Only render summary if it exists */}
                      {article.summary && (
                        <p>{highlightText(article.summary)}</p>
                      )}
                    </div>
                  </article>
                ))}
              </div>
            </div>
          ))
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="pagination">
            <button
              onClick={() => handlePageChange(currentPage - 1)}
              disabled={currentPage === 1}
            >
              {" "}
              Prev{" "}
            </button>
            {getPageNumbers().map((page, index) =>
              typeof page === "number" ? (
                <button
                  key={page}
                  onClick={() => handlePageChange(page)}
                  className={currentPage === page ? "active" : ""}
                  disabled={currentPage === page}
                >
                  {" "}
                  {page}{" "}
                </button>
              ) : (
                <span key={`ellipsis-${index}`} className="ellipsis">
                  {" "}
                  {page}{" "}
                </span>
              )
            )}
            <button
              onClick={() => handlePageChange(currentPage + 1)}
              disabled={currentPage === totalPages}
            >
              {" "}
              Next{" "}
            </button>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="site-footer">
        <div className="footer-left">
          <p>Contact: bkalertcontact@gmail.com</p>
          <p>
            <a
              href="https://www.facebook.com/profile.php?id=61573220511529"
              target="_blank"
              rel="noopener noreferrer"
            >
              Facebook
            </a>
          </p>
        </div>
        <div className="footer-right">
          <p>Scan QR to give feedback:</p>
          <img
            src={feedbackQR}
            alt="Feedback QR Code"
            className="qr-code-image"
            onClick={() => toggleQR("feedback")} // Use toggleQR
            style={{ cursor: "pointer" }}
          />
        </div>
      </footer>

      {/* Floating QR Bubble (Using click toggle from appjsx.txt) */}
      <div className="pen-bubble">
        ✎
        <div className="pen-bubble-box">
          {/* This button toggles the main QR popup to show the 'add' QR */}
          <button
            onClick={() => toggleQR("add")}
            style={{
              border: "none",
              background: "none",
              padding: 0,
              cursor: "pointer",
            }}
          >
            <img
              src={addQR} // Use the addQR image
              alt="Add Article"
              className="pen-hover-qr-image" // Style as needed
              style={{ width: "100px", height: "auto" }} // Example inline style
            />
          </button>
          <p style={{ fontSize: "12px", margin: "5px 0 0 0", color: "#555" }}>
            Add more articles here !
          </p>{" "}
          {/* Example text */}
        </div>
      </div>

      {/* QR Popup (Handles both feedback and add via currentQR state) */}
      {showQR && (
        <div className="qr-popup">
          <button
            onClick={() => setShowQR(false)} // Close button
            style={{
              float: "right",
              cursor: "pointer",
              border: "none",
              background: "transparent",
              fontSize: "1.2em",
              lineHeight: "1",
            }}
            aria-label="Close QR code popup"
          >
            {" "}
            &times;{" "}
          </button>
          <h3 style={{ marginTop: "0", paddingTop: "5px" }}>
            {" "}
            {/* Adjust spacing */}
            Scan to{" "}
            {currentQR === "feedback" ? "give feedback" : "add an article"}
          </h3>
          <img
            src={currentQR === "feedback" ? feedbackQR : addQR}
            alt={`${
              currentQR === "feedback" ? "Feedback" : "Add Article"
            } QR Code`}
            className="qr-popup-image"
          />
        </div>
      )}
    </div> // End App
  );
}
